# Batch Update HTML Bets

When a single match result affects many bets across multiple models (e.g., M5 appears in 36 bets),
use a Python script to batch-update instead of calling `patch()` 36 times.

## Pattern

```python
#!/usr/bin/env python3
"""Batch update match results in HTML file."""
import re
import sys

HTML_PATH = '/root/world-cup/世界杯预测.html'

def update_match(match_id, actual_score, result_logic):
    """
    match_id: e.g. 'M5'
    actual_score: e.g. '4:1'
    result_logic: function(pick, play_type) -> 'win'|'loss'
    """
    with open(HTML_PATH, 'r', encoding='utf-8') as f:
        content = f.read()

    lines = content.split('\n')
    updated = []
    for line in lines:
        if f"matchId: '{match_id}'" in line:
            line = re.sub(r"actualScore: ''", f"actualScore: '{actual_score}'", line)
            # Only update pending bets
            if "result: 'pending'" in line:
                # Extract pick and playType
                pick_match = re.search(r"pick: '([^']*)'", line)
                play_match = re.search(r"playType: '([^']*)'", line)
                if pick_match and play_match:
                    result = result_logic(pick_match.group(1), play_match.group(1))
                    line = re.sub(r"result: 'pending'", f"result: '{result}'", line)
        updated.append(line)

    with open(HTML_PATH, 'w', encoding='utf-8') as f:
        f.write('\n'.join(updated))

# Example: M5 USA 4-1 Paraguay
def usa_vs_paraguay(pick, play_type):
    if play_type == '胜平负':
        return 'win' if pick == '主胜' else 'loss'
    elif play_type == '让球胜平负':
        # 让平(-1): 调整后 3-1, 美国胜, 不是平 → loss
        return 'loss'
    return 'loss'

update_match('M5', '4:1', usa_vs_paraguay)
```

## Key Points

1. **只更新 `result: 'pending'`** — 避免覆盖已结算的投注
2. **过关票的 amount=0 腿** — 这些是配腿，不单独计算奖金，但 result 仍需更新
3. **让球胜平负** — 必须手动计算让球后比分再判定
4. **更新后必须 cp + docker cp + caddy reload** — 否则页面不会刷新
