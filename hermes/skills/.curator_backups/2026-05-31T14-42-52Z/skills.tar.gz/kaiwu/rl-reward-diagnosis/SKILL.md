---
name: rl-reward-diagnosis
description: Diagnose RL agent behavioral issues by analyzing reward structure. Use when the agent exhibits unwanted behavior (random skills, wandering, avoiding combat, etc.) to identify root causes in the reward function.
version: 1.0.0
author: QoobeeHermes
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kaiwu, rl, reward, diagnosis]
    related_skills: [rl-advisor, monitor-analyzer]
---

# RL Reward Diagnosis

诊断智能体行为问题的奖励结构根因。

## When to Use

- 智能体表现出"不合理"行为（乱放技能、徘徊、不打英雄、推塔慢等）
- 团队问"为什么智能体XXX"
- 训练监控中某个 reward 分项异常或 value_loss 某头异常高
- 评估奖励改动的效果

Don't use for: 训练数据抓取（用 monitor-analyzer）、代码位置查找（用 rl-advisor）

## 核心原则

**智能体永远在按奖励规则最优行动。** 如果行为"不合理"，问题一定在奖励结构，不在智能体本身。

## 诊断流程

### Step 1: 读取奖励配置

```python
# 读 conf.py 中的 REWARD_WEIGHT_DICT 和 SKILL_HIT_WEIGHT
# 读 reward_process.py 中的 get_reward() 理解计算方式
```

### Step 2: 对照行为分析信号

将奖励信号按"鼓励/惩罚"和"目标行为/实际行为"画成矩阵，找冲突。

### Step 3: 检查 value_loss 分项

如果某个 value_loss 分项异常高（其他头的10倍以上），说明该维度的值网络拟合失败。

## 常见行为问题诊断清单

详见 `references/reward-diagnosis.md`

## 奖励改动效果评估

改动奖励权重后，观察：
1. 对应 reward 分项是否上升（目标行为增加）
2. 其他 reward 分项是否大幅下降（非目标行为被抑制）
3. win_rate 是否下降
4. 对应 value_loss 是否飙升（值网络拟合失败）
5. episode_frame 是否大幅增加（对局变拖沓）
